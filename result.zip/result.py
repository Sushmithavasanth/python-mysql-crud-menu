import mysql.connector
from mysql.connector import Error
import json
from decimal import Decimal
from datetime import datetime


class CustomEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o)
        elif isinstance(o, datetime):
            return o.isoformat()
        return super(CustomEncoder, self).default(o)

def connect_to_database():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            database='sat_results',
            user='Sushmitha',
            password='152000'
        )
        return conn
    except Error as e:
        print("Error while connecting to the database:", e)
        return None

def view_all_data(cursor):
    try:
        cursor.execute('SELECT * FROM sat_resultstable')
        records = cursor.fetchall()
        json_data = json.dumps(records, indent=2, cls=CustomEncoder)
        print(json_data)
    except Error as query_error:
        print("Error during SQL query:", query_error)

def get_rank(cursor, name):
    try:
        cursor.execute('SELECT name, sat_score FROM sat_resultstable ORDER BY sat_score DESC')
        records = cursor.fetchall()

        names = [record['name'] for record in records]
        scores = [record['sat_score'] for record in records]

        if name in names:
            rank = names.index(name) + 1
            print(f"{name}'s rank: {rank}")
        else:
            print(f"No data found for {name}")

    except Error as query_error:
        print("Error during SQL query:", query_error)


def update_score(cursor, name, new_score):
    try:
        cursor.execute('UPDATE sat_resultstable SET sat_score = %s WHERE name = %s', (new_score, name))
        print("Score updated successfully!")
    except Error as query_error:
        print("Error during SQL query:", query_error)

def delete_record(cursor, name):
    try:
        cursor.execute('DELETE FROM sat_resultstable WHERE name = %s', (name,))
        print("Record deleted successfully!")
    except Error as query_error:
        print("Error during SQL query:", query_error)

def main():
    conn = connect_to_database()
    if not conn:
        return

    try:
        cursor = conn.cursor(dictionary=True)

        while True:
            print("\nMenu:")
            print("1. View all data")
            print("2. Get rank")
            print("3. Update score")
            print("4. Delete one record")
            print("5. Exit")

            choice = input("Enter your choice (1-5): ")

            if choice == '1':
                view_all_data(cursor)
            elif choice == '2':
                name = input("Enter the name to get the rank: ")
                get_rank(cursor, name)
            elif choice == '3':
                name = input("Enter the name to update the score: ")
                new_score = float(input("Enter the new SAT score: "))
                update_score(cursor, name, new_score)
            elif choice == '4':
                name = input("Enter the name to delete the record: ")
                delete_record(cursor, name)
            elif choice == '5':
                break
            else:
                print("Invalid choice. Please enter a number from 1 to 5.")

    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()
            print("Connection closed")

if __name__ == "__main__":
    main()
