-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2023 at 08:44 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sat_results`
--

-- --------------------------------------------------------

--
-- Table structure for table `sat_resultstable`
--

CREATE TABLE `sat_resultstable` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `sat_score` decimal(5,2) DEFAULT NULL,
  `passed` varchar(5) GENERATED ALWAYS AS (case when `sat_score` > 30 then 'Pass' else 'Fail' end) STORED,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sat_resultstable`
--

INSERT INTO `sat_resultstable` (`id`, `name`, `address`, `city`, `country`, `pincode`, `sat_score`, `created_at`, `updated_at`) VALUES
(1, 'Sushmitha', '123 Main St', 'Anytown', 'India', '12345', '75.50', '2023-12-26 15:03:21', '2023-12-26 15:03:21'),
(2, 'Bharathi', '456 2nd St', 'Sometown', 'India', '67890', '60.75', '2023-12-26 15:03:21', '2023-12-26 15:03:21'),
(3, 'Varsha', '789 4th St', 'Anothercity', 'India', '54321', '85.25', '2023-12-26 15:03:22', '2023-12-26 15:03:22'),
(4, 'Divya', '987 6th St', 'YetAnotherCity', 'India', '98765', '45.80', '2023-12-26 15:03:22', '2023-12-26 15:03:22'),
(5, 'Likith', '654 3rd St', 'LastCity', 'India', '24680', '70.00', '2023-12-26 15:03:22', '2023-12-26 15:03:22'),
(6, 'Dilip', '444 8th St', 'FinalCity', 'India', '87653', '20.00', '2023-12-26 15:03:22', '2023-12-26 15:03:22'),
(7, 'Anand', '234 80th St', 'LastCity', 'India', '12567', '26.00', '2023-12-26 15:04:30', '2023-12-26 15:04:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sat_resultstable`
--
ALTER TABLE `sat_resultstable`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sat_resultstable`
--
ALTER TABLE `sat_resultstable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
